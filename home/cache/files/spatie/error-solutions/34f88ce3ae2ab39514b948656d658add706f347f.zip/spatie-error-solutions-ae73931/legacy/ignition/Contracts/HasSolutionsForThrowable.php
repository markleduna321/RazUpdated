<?php

namespace Spatie\Ignition\Contracts;

interface HasSolutionsForThrowable extends \Spatie\ErrorSolutions\Contracts\HasSolutionsForThrowable
{
}
