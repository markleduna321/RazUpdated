<?php

namespace Spatie\Ignition\Contracts;

interface Solution extends \Spatie\ErrorSolutions\Contracts\Solution
{
}
