<?php

namespace Spatie\Ignition\Solutions;

class SolutionTransformer extends \Spatie\ErrorSolutions\Solutions\SolutionTransformer
{
}
