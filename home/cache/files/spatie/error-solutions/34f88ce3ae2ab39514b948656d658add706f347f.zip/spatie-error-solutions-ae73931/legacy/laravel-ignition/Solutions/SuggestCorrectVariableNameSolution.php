<?php

namespace Spatie\LaravelIgnition\Solutions;

use Spatie\ErrorSolutions\Solutions\SuggestCorrectVariableNameSolution as BaseSuggestCorrectVariableNameSolutionAlias;
use Spatie\Ignition\Contracts\Solution;

class SuggestCorrectVariableNameSolution extends BaseSuggestCorrectVariableNameSolutionAlias implements Solution
{

}
